import axios from "axios";

export default {
    userApis: () => require("./userApi")(axios),
    authApis: () => require("./authApis")(axios),
    productApis: () => require("./productApi")(axios),
    categoryApis: () => require("./categoryApis")(axios),
};