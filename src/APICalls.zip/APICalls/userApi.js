const apiConfig = require("../config/api.json");
const token = "asdfafsadf";

module.exports = (axios) => {
    const addNewAdminUser = async (data) => {
        let response;
        try {
            response = await axios({
                url: apiConfig.addNewAdmin.uri,
                method: apiConfig.addNewAdmin.method,
                headers: {
                    authorization: token
                }
            });
        }
        catch(err) {
            console.log(" === ERROR === ", err);
        }
        return response;
    };

    return {
        addNewAdminUser
    };
}

