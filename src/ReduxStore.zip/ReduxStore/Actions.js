export const LOGIN = "LOGIN";
export const CHANGE_TAB = "CHANGE_TAB";
export const SET_PRODUCTS = "SET_PRODUCTS";
export const TOGGLE_ADD_PRODUCT_MODAL = "TOGGLE_ADD_PRODUCT_MODAL";
export const ADD_NEW_PRODUCT = "ADD_NEW_PRODUCT";
export const TOGGLE_EDIT_PRODUCT_MODAL = "TOGGLE_EDIT_PRODUCT_MODAL";
export const UPDATE_PRODUCT = "UPDATE_PRODUCT";
export const FILTER_PRODUCTS = "FILTER_PRODUCTS";
export const TOGGLE_DELETE_PRODUCT_MODAL = "TOGGLE_DELETE_PRODUCT_MODAL";
export const DELETE_PRODUCT = "DELETE_PRODUCT";
export const GET_ALL_CATEGORIES = "GET_ALL_CATEGORIES";
export const TOGGLE_ADD_CATEGORY_MODAL = "TOGGLE_ADD_CATEGORY_MODAL";
export const ADD_CATEGORY = "ADD_CATEGORY";
export const TOGGLE_DELETE_CATEGORY_MODAL = "TOGGLE_DELETE_CATEGORY_MODAL";
export const TOGGLE_EDIT_CATEGORY_MODAL = "TOGGLE_EDIT_CATEGORY_MODAL";
export const UPDATE_CATEGORY = "UPDATE_CATEGORY";

export const loginAction = (data) => {
    return {
        type: LOGIN,
        data: data
    };
};

export const changeTab = (data) => {
    return {
        type: CHANGE_TAB,
        tab: data
    };
};

export const setProducts = (products) => {
    return {
        type: SET_PRODUCTS,
        products: products
    };
};

export const toggleAddProductModal = () => {
    return {
        type: TOGGLE_ADD_PRODUCT_MODAL
    };
};

export const addNewProduct = (product) => {
    return {
        type: ADD_NEW_PRODUCT,
        product: product
    };
};

export const toggleEditProductModal = () => {
    return {
        type: TOGGLE_EDIT_PRODUCT_MODAL
    };
};

export const updateProduct = (productId, product) => {
    return {
        type: UPDATE_PRODUCT,
        productId,
        product,
    };
};

export const filterProducts = (name, category, brand) => {
    return {
        type: FILTER_PRODUCTS,
        name,
        category,
        brand,
    };
};

export const toggleDeleteProductModal = () => {
    return {
        type: TOGGLE_DELETE_PRODUCT_MODAL,
    };
};

export const deleteProduct = (productId) => {
    return {
        type: DELETE_PRODUCT,
        productId,
    };
};

export const getAllCategories = (categories) => {
    return {
        type: GET_ALL_CATEGORIES,
        categories,
    };
};

export const toggleAddCategoryModal = () => {
    return {
        type: TOGGLE_ADD_CATEGORY_MODAL
    };
};

export const addCategory = (category) => {
    return {
        type: ADD_CATEGORY,
        category,
    }
}

export const toggleDeleteCategoryModal = () => {
    return {
        type: TOGGLE_DELETE_CATEGORY_MODAL
    }
}

export const toggleEditCategoryModal = category => {
    return {
        type: TOGGLE_EDIT_CATEGORY_MODAL
    }
}

export const updateCategory = (categoryId, category) => {
    return {
        type: UPDATE_CATEGORY,
        categoryId,
        category,
    };
};